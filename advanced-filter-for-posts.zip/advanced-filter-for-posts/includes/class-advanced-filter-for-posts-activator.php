<?php

/**
 * Fired during plugin activation
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.1
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/includes
 * @author     Rohit <rohitsaini1328@gmail.com>
 */
class Advanced_Filter_For_Posts_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.1
	 */
	public static function activate() {

	}

}
