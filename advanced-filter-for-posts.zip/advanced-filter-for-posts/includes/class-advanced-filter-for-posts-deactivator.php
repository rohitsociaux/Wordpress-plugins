<?php

/**
 * Fired during plugin deactivation
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.1
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/includes
 * @author     Rohit <rohitsaini1328@gmail.com>
 */
class Advanced_Filter_For_Posts_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.1
	 */
	public static function deactivate() {

	}

}
