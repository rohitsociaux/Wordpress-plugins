<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/public/partials
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

add_action('wp_ajax_wp_advance_filter_load_posts', 'demodata_load_posts');
add_action('wp_ajax_nopriv_wp_advance_filter_load_posts', 'demodata_load_posts');
function demodata_load_posts() {
    // Check if nonce exists and verify it
    if (!isset($_POST['nonce']) || !wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['nonce'])), 'demodata_nonce')) {
        wp_send_json_error(array('message' => __('Nonce verification failed', 'advanced-filter-for-posts')));
    }

    // Sanitize and validate all inputs
    $paged = isset($_POST['page']) ? absint($_POST['page']) : 1;
    $categories = isset($_POST['categories']) ? array_map('sanitize_text_field', wp_unslash((array) $_POST['categories'])) : [];
    $tags = isset($_POST['tags']) ? array_map('sanitize_text_field', wp_unslash((array) $_POST['tags'])) : [];
    $search = isset($_POST['search']) ? sanitize_text_field(wp_unslash($_POST['search'])) : '';
    $shortcode_atts = isset($_POST['shortcode_atts']) ? array_map('sanitize_text_field', wp_unslash((array) $_POST['shortcode_atts'])) : [];
    $view_type = isset($_POST['view_type']) ? sanitize_text_field(wp_unslash($_POST['view_type'])) : 'grid';

    // Sanitize and set default values for post_type and posts_per_page
    $post_type = !empty($shortcode_atts['post_type']) ? sanitize_key($shortcode_atts['post_type']) : 'post';
    $per_page = !empty($shortcode_atts['posts_per_page']) ? absint($shortcode_atts['posts_per_page']) : 9;

     $post_order = !empty($shortcode_atts['order']) ? sanitize_key($shortcode_atts['order']) : 'ASC';

    // Set up the WP_Query arguments
    $args = array(
        'post_type'      => $post_type,
        'post_status'    => 'publish',
        'posts_per_page' => $per_page,
        'paged'          => $paged,
        's'              => $search,
        'order'     => $post_order,  
    );

    // Handle categories and tags
    if (!empty($categories)) {
        $args['category_name'] = implode(',', array_map('sanitize_title', $categories));
    }

    if (!empty($tags)) {
        $args['tag'] = implode(',', array_map('sanitize_title', $tags));
    }

    // Run the query
    $query = new WP_Query($args);
    ob_start();
    if ($query->have_posts()) {
        while ($query->have_posts()) {
            $query->the_post();
            $post_categories = wp_get_post_categories(get_the_ID(), ['fields' => 'slugs']);
            $post_tags_obj = wp_get_post_tags(get_the_ID());
            $post_tags = wp_list_pluck($post_tags_obj, 'slug');
            require plugin_dir_path(__FILE__) . 'wp_advance_loop_data.php';
        }
    } else {
        echo '<p class="no_post_found">' . esc_html__('No posts found.', 'advanced-filter-for-posts') . '</p>';
    }
    $posts_html = ob_get_clean();

    // Pagination
    ob_start();
    $total_pages = $query->max_num_pages;
    if ($total_pages > 1) {
        echo '<div class="wp_advance_filter_pagination">';
        if ($paged > 1) {
            echo '<button class="wp_advance_filter_pagination_prev" data-page="' . esc_attr($paged - 1) . '">' . esc_html__('Previous', 'advanced-filter-for-posts') . '</button>';
        }
        $start = max(1, $paged - 2);
        $end = min($total_pages, $paged + 2);

        if ($start > 1) {
            echo '<button data-page="1">' . esc_html('1') . '</button>';
            if ($start > 2) echo '<span class="wp_advance_filter_pagination_dots">...</span>';
        }

        for ($i = $start; $i <= $end; $i++) {
            echo '<button class="' . esc_attr(($i == $paged ? 'active' : '')) . '" data-page="' . esc_attr($i) . '">' . esc_html($i) . '</button>';
        }

        if ($end < $total_pages) {
            if ($end < $total_pages - 1) echo '<span class="wp_advance_filter_pagination_dots">...</span>';
            echo '<button data-page="' . esc_attr($total_pages) . '">' . esc_html($total_pages) . '</button>';
        }

        if ($paged < $total_pages) {
            echo '<button class="wp_advance_filter_pagination_next" data-page="' . esc_attr($paged + 1) . '">' . esc_html__('Next', 'advanced-filter-for-posts') . '</button>';
        }

        echo '</div>';
    }
    $pagination_html = ob_get_clean();

    // Reset the query and send the response
    wp_reset_postdata();
    wp_send_json_success(array(
        'posts' => $posts_html,
        'pagination' => $pagination_html
    ));

    wp_die();
}
