<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/public/partials
 */

if (!defined('ABSPATH')) {
    exit;
}

if (!isset($atts['hide_categories']) || $atts['hide_categories'] !== 'yes') : 
    $all_categories = get_categories(array(
        'fields'     => 'ids',
        'hide_empty' => false,
    ));
    
    $uncategorized_id = get_cat_ID('Uncategorized');
    $include_ids = array_diff($all_categories, array($uncategorized_id));
    $categories = get_categories(apply_filters('wp_advanced_post_filters_category_args', array(
        'hide_empty' => true,
        'orderby'    => 'name',
        'order'      => 'ASC',
        'include'    => $include_ids
    )));
    
    if (!empty($categories)) : ?>
        <div class="wp_advance_filter_group">
            <div class="wp_advance_filter_group_header">
                <h2><?php echo esc_html__('Categories', 'advanced-filter-for-posts'); ?></h2>
                <svg class="wp_advance_filter_accordion_icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <polyline points="6 9 12 15 18 9"></polyline>
                </svg>
            </div>
            <div class="wp_advance_filter_group_content">
                <div class="wp_advance_filter_list" id="wp_advance_filter_category_list">
                    <?php foreach ($categories as $category) : 
                        $checked = isset($url_params['categories']) && in_array($category->slug, (array)$url_params['categories']);
                        ?>
                        <label class="wp_advance_filter_item">
                            <input type="checkbox" 
                                   name="categories[]" 
                                   value="<?php echo esc_attr($category->slug); ?>" 
                                   <?php checked($checked); ?>
                                   class="wp_advance_filter_checkbox">
                            <span class="wp_advance_filter_label">
                                <?php echo esc_html($category->name); ?>
                                <span class="wp_advance_filter_count">(<?php echo esc_html($category->count); ?>)</span>
                            </span>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    <?php endif;
endif; ?>