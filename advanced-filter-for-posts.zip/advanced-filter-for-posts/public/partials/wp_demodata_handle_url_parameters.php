<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/public/partials
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

function demodata_handle_url_parameters() {
    if (is_singular() && has_shortcode(get_post()->post_content, 'wp_advanced_filter')) {
        // Verify nonce for security
        if (isset($_GET['_wpnonce']) && !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'demodata_url_parameters')) {
            wp_die('Nonce verification failed', 'Error', array('response' => 403));
        }

        $params = array();

        // Handle cat_filter parameter
        if (!empty($_GET['cat_filter'])) {
            $cat_filter = sanitize_text_field(wp_unslash($_GET['cat_filter']));
            $params['categories'] = array_filter(explode(',', $cat_filter));
        }

        // Handle tag_filter parameter
        if (!empty($_GET['tag_filter'])) {
            $tag_filter = sanitize_text_field(wp_unslash($_GET['tag_filter']));
            $params['tags'] = array_filter(explode(',', $tag_filter));
        }

        // Handle search parameter
        if (!empty($_GET['search'])) {
            $params['search'] = sanitize_text_field(wp_unslash($_GET['search']));
        }

        // Handle view parameter
        if (!empty($_GET['view'])) {
            $view = sanitize_text_field(wp_unslash($_GET['view']));
            $params['view'] = in_array($view, array('grid', 'list')) ? $view : 'grid';
        }

        // If params exist, localize the script with the parameters
        if (!empty($params)) {
            wp_localize_script('wp_advance_filter_js', 'demodata_url_params', $params);
        }
    }
}