<?php

/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/public/partials
 */

add_shortcode('wp_advanced_filter', 'demodata_render_shortcode');
function demodata_render_shortcode($atts) {
    // Verify nonce for security
    if (isset($_GET['_wpnonce']) && !wp_verify_nonce(sanitize_text_field(wp_unslash($_GET['_wpnonce'])), 'wp_advanced_filter_nonce')) {
        return '<p class="wp-advanced-filter-error">' . esc_html__('Nonce verification failed. Please try again.', 'advanced-filter-for-posts') . '</p>';
    }

    // Set default attributes with proper sanitization
    $default_atts = array(
        'post_type'        => 'post',
        'posts_per_page'   => 9,
        'categories'      => 'category',
        'tags'            => 'post_tag',
        'hide_tags'       => 'no',
        'hide_categories' => 'no',
        'default_view'    => 'grid',
        'order'           => 'ASC',
        'show_search'     => 'yes',
    );

    // Parse shortcode attributes with defaults
    $atts = shortcode_atts($default_atts, $atts, 'wp_advanced_filter');

    // Sanitize all attributes
    $sanitized_atts = array(
        'post_type'        => sanitize_key($atts['post_type']),
        'posts_per_page'   => absint($atts['posts_per_page']),
        'categories'       => sanitize_text_field($atts['categories']),
        'tags'             => sanitize_text_field($atts['tags']),
        'hide_tags'        => ($atts['hide_tags'] === 'yes') ? 'yes' : 'no',
        'hide_categories'  => ($atts['hide_categories'] === 'yes') ? 'yes' : 'no',
        'default_view'     => in_array($atts['default_view'], array('grid', 'list')) ? $atts['default_view'] : 'grid',
        'order'            => in_array(strtoupper($atts['order']), array('ASC', 'DESC')) ? strtoupper($atts['order']) : 'ASC',
        'show_search'      => ($atts['show_search'] === 'yes') ? 'yes' : 'no',
    );

    // Process URL parameters with proper sanitization
    $url_params = array();

    if (!empty($_GET['cat_filter'])) {
        $cat_filter_raw = sanitize_text_field(wp_unslash($_GET['cat_filter']));
        $url_params['categories'] = array_filter(array_map('sanitize_text_field', explode(',', $cat_filter_raw)));
    }

    if (!empty($_GET['tag_filter'])) {
        $tag_filter_raw = sanitize_text_field(wp_unslash($_GET['tag_filter']));
        $url_params['tags'] = array_filter(array_map('sanitize_text_field', explode(',', $tag_filter_raw)));
    }

    if (!empty($_GET['search'])) {
        $url_params['search'] = sanitize_text_field(wp_unslash($_GET['search']));
    }

    if (!empty($_GET['view'])) {
        $view_raw = sanitize_text_field(wp_unslash($_GET['view']));
        $url_params['view'] = in_array($view_raw, array('grid', 'list'), true) ? $view_raw : $sanitized_atts['default_view'];
    }

    ob_start();
    ?>
    <div id="wp_advance_filter_data" 
         data-args='<?php echo esc_attr(wp_json_encode($sanitized_atts)); ?>'
         data-url-params='<?php echo esc_attr(wp_json_encode($url_params)); ?>'>
    </div>
    
    <?php 
    // Include template files safely
    $template_path = plugin_dir_path(__FILE__);
    
    if (file_exists($template_path . 'wp_advance_filter_ht.php')) {
        include $template_path . 'wp_advance_filter_ht.php';
    }
    ?>
    
    <div class="wp_advance_filter_container">
        <?php if ($sanitized_atts['hide_categories'] !== 'yes' || $sanitized_atts['hide_tags'] !== 'yes') : ?>
            <aside id="wp_advance_filter_sidebar" class="wp_advance_filter_sidebar">
                <?php 
                if (file_exists($template_path . 'wp_advance_category.php')) {
                    include $template_path . 'wp_advance_category.php';
                }
                if (file_exists($template_path . 'wp_advance_tag.php')) {
                    include $template_path . 'wp_advance_tag.php';
                }
                ?>
            </aside>
        <?php endif; ?>

        <!-- Loading spinner -->
        <div id="wp_advance_filter_loader" class="wp_advance_filter_loader hidden">
            <div class="wp_spinner"></div>
        </div>

        <!-- Main content wrapper for posts -->
        <main class="main_post_data">
            <div id="wp_advance_filter_post_wrapper"
                 class="wp_advance_filter_posts wp_advance_filter_<?php echo esc_attr(isset($url_params['view']) ? $url_params['view'] : $sanitized_atts['default_view']); ?>">
            </div>
            <div id="pagination_data"></div>
        </main>
    </div>
    <?php
    return ob_get_clean();
}
require plugin_dir_path(__FILE__) . 'wp_advance_fun_ajax.php'; 
require plugin_dir_path(__FILE__) . 'wp_demodata_handle_url_parameters.php'; ?>