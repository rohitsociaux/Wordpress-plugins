<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/public/partials
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

 if (!isset($atts['hide_tags']) || $atts['hide_tags'] !== 'yes') :  ?>
    <div class="wp_advance_filter_group">
        <div class="wp_advance_filter_group_header">
            <h2><?php echo esc_html__('Tags', 'advanced-filter-for-posts'); ?></h2>
            <svg class="wp_advance_filter_accordion_icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <polyline points="6 9 12 15 18 9"></polyline>
            </svg>
        </div>
        <div class="wp_advance_filter_group_content">
            <div class="wp_advance_filter_list" id="wp_advance_filter_tag_list">
                <?php
                $tags = get_tags(array('hide_empty' => true));
                foreach ($tags as $tag) {
                    $checked = isset($url_params['tags']) && in_array($tag->slug, $url_params['tags']);
                    ?>
                    <label>
                        <input type="checkbox" value="<?php echo esc_attr($tag->slug); ?>" <?php echo $checked ? 'checked' : ''; ?>>
                        <?php echo esc_html($tag->name); ?>
                        <span class="wp_advance_filter_count">(<?php echo esc_html($tag->count); ?>)</span>
                    </label>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>
<?php endif; ?>
