<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/public/partials
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}
?>
<div class="wp_advance_filter_post <?php echo esc_attr($view_type); ?>"
    <?php if (!empty($post_categories)) : ?>
        data-category="<?php echo esc_attr(implode(' ', $post_categories)); ?>"
    <?php endif; ?>
    <?php if (!empty($post_tags)) : ?>
        data-tags="<?php echo esc_attr(implode(' ', $post_tags)); ?>"
    <?php endif; ?>>

    <?php if (has_post_thumbnail()) : ?>
        <div class="wp_advance_filter_thumbnail">
            <a href="<?php the_permalink(); ?>">
                <?php
                echo wp_get_attachment_image(
                    get_post_thumbnail_id(get_the_ID()),
                    'medium_large',
                    false,
                    array(
                        'class' => 'wp_lazy_load',
                        'loading' => 'lazy',
                        'alt' => esc_attr(get_the_title()),
                    )
                );
                ?>
            </a>
        </div>
    <?php endif; ?>

    <div class="wp_advance_filter_content">
        <?php if (get_the_title()) : ?>
            <h3 class="wp_advance_filter_title"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
        <?php endif; ?>

        <?php if (get_the_date()) : ?>
            <div class="wp_advance_filter_meta">
                <span class="wp_advance_filter_date"><?php echo get_the_date(); ?></span>
            </div>
        <?php endif; ?>

        <?php if (get_the_excerpt()) : ?>
            <p class="wp_advance_filter_excerpt"><?php echo esc_html(wp_trim_words(get_the_excerpt(), 20)); ?></p>
        <?php endif; ?>

        <a href="<?php the_permalink(); ?>" class="wp_advance_filter_post_readmore"><?php echo esc_html__('Read More →', 'advanced-filter-for-posts'); ?></a>
    </div>
</div>
