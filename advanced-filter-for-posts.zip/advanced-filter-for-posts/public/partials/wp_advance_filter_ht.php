<?php
/**
 * Provide a public-facing view for the plugin
 *
 * This file is used to markup the public-facing aspects of the plugin.
 *
 * @link       https://informationtechnologyhouses.in/contact
 * @since      1.0.1
 *
 * @package    Advanced_Filter_For_Posts
 * @subpackage Advanced_Filter_For_Posts/public/partials
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Initialize variables safely
$atts = isset( $atts ) ? $atts : array();
$url_params = isset( $url_params ) ? $url_params : array();

// Set default values
$defaults = array(
    'show_search'   => 'no',
    'default_view'  => 'grid'
);

$atts = wp_parse_args( $atts, $defaults );
?>
<div class="wp_advance_filter_topbar">
    <?php if ( ! empty( $atts['show_search'] ) && 'yes' === $atts['show_search'] ) : ?>
        <input type="text" 
               id="wp_advance_filter_search" 
               class="wp_advance_filter_search" 
               placeholder="<?php echo esc_attr__( 'Search posts...', 'advanced-filter-for-posts' ); ?>"
               value="<?php echo isset( $url_params['search'] ) ? esc_attr( sanitize_text_field( $url_params['search'] ) ) : ''; ?>">
    <?php endif; ?>

    <div class="wp_advance_filter_view_buttons">
        <button id="wp_advance_filter_grid_btn" 
                class="wp_advance_filter_view_btn <?php echo ( ( ! isset( $url_params['view'] ) && 'grid' === $atts['default_view'] ) || ( isset( $url_params['view'] ) && 'grid' === $url_params['view'] ) ) ? 'active' : ''; ?>" 
                type="button" 
                data-view="grid"
                aria-label="<?php esc_attr_e( 'Grid view', 'advanced-filter-for-posts' ); ?>">
            <svg class="wp_advance_filter_icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="3" y="3" width="7" height="7"></rect>
                <rect x="14" y="3" width="7" height="7"></rect>
                <rect x="14" y="14" width="7" height="7"></rect>
                <rect x="3" y="14" width="7" height="7"></rect>
            </svg>
            <span><?php echo esc_html__( 'Grid', 'advanced-filter-for-posts' ); ?></span>
        </button>
        
        <button id="wp_advance_filter_list_btn" 
                class="wp_advance_filter_view_btn <?php echo ( isset( $url_params['view'] ) && 'list' === $url_params['view'] ) ? 'active' : ''; ?>" 
                type="button" 
                data-view="list"
                aria-label="<?php esc_attr_e( 'List view', 'advanced-filter-for-posts' ); ?>">
            <svg class="wp_advance_filter_icon" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <line x1="8" y1="6" x2="21" y2="6"></line>
                <line x1="8" y1="12" x2="21" y2="12"></line>
                <line x1="8" y1="18" x2="21" y2="18"></line>
                <line x1="3" y1="6" x2="3.01" y2="6"></line>
                <line x1="3" y1="12" x2="3.01" y2="12"></line>
                <line x1="3" y1="18" x2="3.01" y2="18"></line>
            </svg>
            <span><?php echo esc_html__( 'List', 'advanced-filter-for-posts' ); ?></span>
        </button>
    </div>

    <button class="wp_advance_filter_mobile_toggle" 
            type="button" 
            aria-expanded="false" 
            aria-controls="wp_advance_filter_sidebar"
            aria-label="<?php esc_attr_e( 'Toggle filters', 'advanced-filter-for-posts' ); ?>">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M3 12H21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M3 6H21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
            <path d="M3 18H21" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
        </svg>
        <span class="wp_advance_filter_mobile_toggle_text"><?php echo esc_html__( 'Filters', 'advanced-filter-for-posts' ); ?></span>
    </button>
</div>