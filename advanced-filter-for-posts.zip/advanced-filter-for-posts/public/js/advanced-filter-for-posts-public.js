jQuery(document).ready(function($) {
    var $container = $('.wp_advance_filter_container');
    var $postWrapper = $('#wp_advance_filter_post_wrapper');
    var $loader = $('#wp_advance_filter_loader');
    var $searchInput = $('#wp_advance_filter_search');
    var $mobileToggle = $('.wp_advance_filter_mobile_toggle');
    var $sidebar = $('#wp_advance_filter_sidebar');
    var $filterGroups = $('.wp_advance_filter_group');
    var $paginationWrapper = $('#pagination_data');
    var shortcodeArgs = JSON.parse($('#wp_advance_filter_data').attr('data-args'));
    var urlParams = JSON.parse($('#wp_advance_filter_data').attr('data-url-params'));
    var currentPage = 1;
    var currentView = urlParams.view || shortcodeArgs.default_view || 'grid';
    var searchTimer = null;
    if (urlParams.categories || urlParams.tags) {
        $filterGroups.find('.wp_advance_filter_group_content').addClass('active');
        $filterGroups.find('.wp_advance_filter_accordion_icon').addClass('active');
    }
    
    $postWrapper.addClass(currentView);
    $('#' + currentView + '_btn').addClass('active');
    
    loadPosts();
    
    $('.wp_advance_filter_list input[type="checkbox"]').on('change', function() {
        currentPage = 1;
        updateUrl();
        loadPosts();
    });
    
    $searchInput.on('input', function() {
        clearTimeout(searchTimer);
        searchTimer = setTimeout(function() {
            currentPage = 1;
            updateUrl();
            loadPosts();
        }, 500);
    });
    
    $('#wp_advance_filter_grid_btn, #wp_advance_filter_list_btn').on('click', function() {
        var $this = $(this);
        if ($this.hasClass('active')) return;
        $('.wp_advance_filter_view_btn').removeClass('active');
        $this.addClass('active');
        currentView = $this.attr('id').replace('wp_advance_filter_', '').replace('_btn', '');
        $postWrapper.removeClass('grid list').addClass(currentView);
        updateUrl();
        loadPosts();
    });
    
    $(document).on('click', '.wp_advance_filter_pagination button', function(e) {
        e.preventDefault();
        currentPage = $(this).data('page');
        loadPosts();
        $('html, body').animate({
            scrollTop: $postWrapper.offset().top - 100
        }, 500);
    });
    
    $('#wp_advance_filter_category_btn').on('click', function() {
        toggleExtraItems('#wp_advance_filter_category_list', 'wp_advance_filter_extra_category', $(this));
    });
    
    $('#wp_advance_filter_tag_btn').on('click', function() {
        toggleExtraItems('#wp_advance_filter_tag_list', 'wp_advance_filter_extra_tag', $(this));
    });
    
    $mobileToggle.on('click', function() {
        $sidebar.toggleClass('active');
        $(this).toggleClass('active');
    });
    
    // Accordion toggle
    $('.wp_advance_filter_group_header').on('click', function() {
        var $header = $(this);
        var $content = $header.next('.wp_advance_filter_group_content');
        var $icon = $header.find('.wp_advance_filter_accordion_icon');
        
        $content.slideToggle(300);
        $icon.toggleClass('active');
    });
    
    function loadPosts() {
        $loader.removeClass('hidden grid list').addClass(currentView);
        var selectedCategories = [];
        $('#wp_advance_filter_category_list input[type="checkbox"]:checked').each(function() {
            selectedCategories.push($(this).val());
        });
        
        var selectedTags = [];
        $('#wp_advance_filter_tag_list input[type="checkbox"]:checked').each(function() {
            selectedTags.push($(this).val());
        });
        var searchTerm = $searchInput.val();
        $.ajax({
            url: demodata_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'wp_advance_filter_load_posts',
                nonce: demodata_ajax.nonce,
                page: currentPage,
                categories: selectedCategories,
                tags: selectedTags,
                search: searchTerm,
                shortcode_atts: shortcodeArgs,
                view_type: currentView
            },
            success: function(response) {
                if (response.success) {
                    $postWrapper.html(response.data.posts);
                    $paginationWrapper.html(response.data.pagination);
                    $loader.addClass('hidden');
                    // Re-apply view class in case it was lost during AJAX
                    $postWrapper.removeClass('grid list').addClass(currentView);
                }
            },
            error: function(xhr, status, error) {
                console.error(error);
                $loader.addClass('hidden');
                $postWrapper.html('<p class="error">' + demodata_ajax.error_message + '</p>');
            }
        });
    }
    
    // Function to toggle extra items
    function toggleExtraItems(listSelector, itemClass, $button) {
        var $list = $(listSelector);
        var $items = $list.find('.' + itemClass);
        
        if ($items.hasClass('wp_advance_filter_hidden')) {
            $items.removeClass('wp_advance_filter_hidden');
            $button.text(demodata_ajax.read_less);
        } else {
            $items.addClass('wp_advance_filter_hidden');
            $button.text(demodata_ajax.read_more);
        }
    }
    
    // Function to update URL with current filters
    function updateUrl() {
        var selectedCategories = [];
        $('#wp_advance_filter_category_list input[type="checkbox"]:checked').each(function() {
            selectedCategories.push($(this).val());
        });
        
        var selectedTags = [];
        $('#wp_advance_filter_tag_list input[type="checkbox"]:checked').each(function() {
            selectedTags.push($(this).val());
        });
        
        var searchTerm = $searchInput.val();
        var params = {};
        
        if (selectedCategories.length > 0) {
            params.cat_filter = selectedCategories.join(',');
        }
        
        if (selectedTags.length > 0) {
            params.tag_filter = selectedTags.join(',');
        }
        
        if (searchTerm) {
            params.search = searchTerm;
        }
        
        if (currentView !== shortcodeArgs.default_view) {
            params.view = currentView;
        }
        
        var url = window.location.pathname;
        var queryString = $.param(params);
        
        if (queryString) {
            url += '?' + queryString;
        }
        
        // Update URL without reloading
        history.pushState(null, null, url);
    }
    
    // If URL parameters exist, trigger filter
    if (urlParams.categories || urlParams.tags || urlParams.search) {
        // Check checkboxes based on URL params
        if (urlParams.categories) {
            urlParams.categories.forEach(function(cat) {
                $('#wp_advance_filter_category_list input[value="' + cat + '"]').prop('checked', true);
            });
        }
        
        if (urlParams.tags) {
            urlParams.tags.forEach(function(tag) {
                $('#wp_advance_filter_tag_list input[value="' + tag + '"]').prop('checked', true);
            });
        }
        
        // Trigger initial load
        loadPosts();
    }
});